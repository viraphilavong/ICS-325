<?php
/**
 * Created by PhpStorm.
 * User: marty
 * Date: 6/12/2016
 * Time: 7:48 PM
 */
?>

<div id="footer">
    <hr />
    Copyright &copy; 2016 The Comic Book
</div>
